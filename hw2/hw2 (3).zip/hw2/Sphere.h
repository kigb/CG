#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <iostream>
class Sphere {
public:
    glm::vec3 center; // ��������
    float radius;     // ����뾶
    std::vector<glm::vec3> vertices; // ����Ķ���

    Sphere(glm::vec3 center, float radius) : center(center), radius(radius) {
        generateVertices();
    }
    void move(glm::vec3 displacement);

private:
    void generateVertices();
    
    
};

