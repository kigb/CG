#include "model.h"

void model::processMesh(aiMesh* mesh) {

    for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
        aiVector3D vertex = mesh->mVertices[i];
        aiVector3D normal = mesh->mNormals[i];

        // 将 aiVector3D 转换为 glm::vec3
        glm::vec3 gl_vertex(vertex.x, vertex.y, vertex.z);
        glm::vec3 gl_normal(normal.x, normal.y, normal.z);
        glm::vec3 shrunkVertex = gl_vertex - gl_normal * shrinkDistance;

        shrunkVertices.push_back(shrunkVertex);
        originalVertices.push_back(gl_vertex);

    }
    size = shrunkVertices.size();
}

void model::loadModel(const std::string& path) {
    Assimp::Importer importer;
    const aiScene* scene = importer.ReadFile(path, aiProcess_Triangulate | aiProcess_FlipUVs | aiProcess_GenNormals);

    if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode) {
        std::cout << "ERROR::ASSIMP::" << importer.GetErrorString() << std::endl;
        return;
    }

    std::cout << "Loaded model successfully." << std::endl;

    // 遍历每个网格
    for (unsigned int i = 0; i < scene->mNumMeshes; i++) {
        processMesh(scene->mMeshes[i]);
    }
}



