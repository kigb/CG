#pragma once
#include <iostream>
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include <vector>
#include <string>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
class model
{
private:
	std::string filename;
	const float shrinkDistance = 0.02f;//内缩距离
	int size;
	
public:
	model(std::string s) {
		filename = s;
		loadModel(s);
	}
	std::string get_filename() {
		return filename;
	}
	int get_size() {
		return size;
	}
	void processMesh(aiMesh* mesh);
	void loadModel(const std::string& path);
	std::vector<glm::vec3> originalVertices;
	std::vector<glm::vec3> shrunkVertices;
	std::vector<unsigned int> indices;
	

};

