#include "Sphere.h"
#define M_PI 3.1415
void Sphere::generateVertices() {
    const unsigned int X_SEGMENTS = 64;
    const unsigned int Y_SEGMENTS = 64;
    for (unsigned int y = 0; y <= Y_SEGMENTS; ++y) {
        for (unsigned int x = 0; x <= X_SEGMENTS; ++x) {
            float xSegment = (float)x / (float)X_SEGMENTS;
            float ySegment = (float)y / (float)Y_SEGMENTS;
            float xPos = std::cos(xSegment * 2.0f * M_PI) * std::sin(ySegment * M_PI) * radius;
            float yPos = std::cos(ySegment * M_PI) * radius;
            float zPos = std::sin(xSegment * 2.0f * M_PI) * std::sin(ySegment * M_PI) * radius;

            vertices.push_back(glm::vec3(xPos, yPos, zPos) + center);
        }
    }
}
void Sphere::move(glm::vec3 displacement) {
    center += displacement;
    for (auto& v : vertices) {
        v += displacement;
    }
}